console.log('First');

setTimeout(() => {
  console.log('Last');
}, 100);

console.log('Second');

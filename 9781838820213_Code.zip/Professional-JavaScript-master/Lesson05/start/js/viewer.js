// Page elements and variables
let bulb = document.getElementById("bulb");
let slider = document.getElementById("brightnessSlider");
let onImage = "images/bulb_on.png";
let offImage = "images/bulb_off.png";

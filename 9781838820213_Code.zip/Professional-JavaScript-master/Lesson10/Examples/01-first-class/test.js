require('./example-1-functions-as-values');
// Require('./example-2-add-event-listener');
require('./example-3-fs-readdir-callback');
require('./example-4-fetch-then');
require('./example-5-fs-readdir-promise');
require('./example-6-array-first-class');

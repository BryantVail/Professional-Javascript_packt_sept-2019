module.exports = {
  server: {
    command: 'npm start',
    port: 8080,
  },
}
